This is stracker, a server side app for assetto corsa servers collecting statistics.

Author: Neys
Homepages: 
    http://www.racedepartment.com/downloads/stracker.3510/
    http://n-e-y-s.de
    http://www.assettocorsa.net/forum/index.php?threads/ptracker-stracker.13169/

----------
DISCLAIMER
----------

Server admins decide to run this software on their own judgement. The software 
creates a database where personal information of players is stored and processed, 
including their Steam GUID, nick name, chat history and game play statistics. This 
might require  special efforts to ensure that the offered service obeys to national 
and international laws and policies.
Please understand that this software is a private hobby project and so the software
might not fit to current or future legal regulations, including, but not limited to,
the EU GDPR (https://www.eugdpr.org/). It may even be illegal to run this software
on a public server. You are running this software on your own risk.

-------
LICENSE
-------

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

------------------------------------
stracker Documentation 
------------------------------------
Documentation can be found here: http://n-e-y-s.de/stracker_doc

---------------
Version History
---------------
Please see http://n-e-y-s.de/stracker_doc for the version history
